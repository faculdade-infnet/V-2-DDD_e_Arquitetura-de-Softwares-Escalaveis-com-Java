package br.edu.infnet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Dr4E6A2StreamConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
