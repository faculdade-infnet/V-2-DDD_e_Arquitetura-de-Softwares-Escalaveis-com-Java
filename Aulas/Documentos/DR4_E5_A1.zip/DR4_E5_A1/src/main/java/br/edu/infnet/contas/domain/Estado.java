package br.edu.infnet.contas.domain;

public enum Estado {
    CRIADA, ATIVADA, BLOQUEADA
}
