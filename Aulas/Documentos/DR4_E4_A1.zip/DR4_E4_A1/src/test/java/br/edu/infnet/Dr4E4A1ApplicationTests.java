package br.edu.infnet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Dr4E4A1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
